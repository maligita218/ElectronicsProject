package com.BikkadIt;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ElectronicsStoreApplicationTests {

	@Test
	void contextLoads() {
	}

}
